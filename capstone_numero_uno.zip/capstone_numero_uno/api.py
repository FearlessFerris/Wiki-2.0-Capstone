# API Links and Keys

# Page Search API LINK
SEARCH_PAGE_BASE = 'https://en.wikipedia.org/w/rest.php/v1/search/page'

# Page Object API URL
GET_PAGE_BASE = 'https://en.wikipedia.org/w/rest.php/v1/page/'